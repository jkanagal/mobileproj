package com.example.myapplication_mobileproj;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

   VideoView video1;
    Button login;
    EditText username,password,repassword;
    Button signup,signin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      //  login=(Button)findViewById(R.id.login_button);
        username=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);
       repassword=(EditText)findViewById(R.id.repassword);

        signup=(Button)findViewById(R.id.btnsignup);
        signin=(Button)findViewById(R.id.btnsignin);
        DB=new DBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String user=username.getText().toString();
            String pass=password.getText().toString();
            String repass= repassword.getText().toString();

            if(user.equals("")||pass.equals("")||repass.equals(""))
                Toast.makeText(MainActivity.this,"Please enter all fields",Toast.LENGTH_SHORT).show();
            else{
                if(pass.equals(repass)){
                    Boolean checkuser = DB.checkusername(user);
                    if(checkuser==false){
                        Boolean insert =DB.insertData(user,pass);
                        if(insert==true){
                            Toast.makeText(MainActivity.this, "registered succesfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),homeactivity.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(MainActivity.this, "registered failed", Toast.LENGTH_SHORT).show();
                        }

                    }else{

                        Toast.makeText(MainActivity.this, "user already exists,sign-in", Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(MainActivity.this, "passwords dont match", Toast.LENGTH_SHORT).show();
                }
            }

            }
        });


        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent intent = new Intent(getApplicationContext(),loginactivity.class);
            startActivity(intent);
            }
        });

        video1= (VideoView)findViewById(R.id.video1);
        String path="android.resource://com.example.myapplication_mobileproj/"+R.raw.dashcam;
                Uri u= Uri.parse(path);
        video1.setVideoURI(u);
        video1.start();

        video1.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.setLooping(true);
            }
        });

    }

//
//    @Override
//    protected void onResume(){
//        video1.resume();
//        super.onResume();
//    }
//
//
//    @Override
//    protected void onPause(){
//        video1.suspend();
//        super.onPause();
//    }
//
//
//    @Override
//    protected void onDestroy(){
//        video1.stopPlayback();
//        super.onDestroy();
//    }

}